<?php
// phpcs:ignoreFile
/**
 * Google fonts array file.
 *
 * @package     CartFlows
 * @author      CartFlows Inc
 * @copyright   Copyright (c) 2021, CartFlows Inc
 * @link        https://cartflows.com/
 */

/**
 * Returns google fonts array
 *
 * @since 1.6.10
 */
return array(
	array(
		'ABeeZee' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'ADLaM Display' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'AR One Sans' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Abel' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Abhaya Libre' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Aboreto' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Abril Fatface' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Abyssinica SIL' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Aclonica' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Acme' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Actor' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Adamina' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Advent Pro' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Afacad' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Afacad Flux' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Agbalumo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Agdasima' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Agu Display' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Aguafina Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Akatab' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Akaya Kanadaka' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Akaya Telivigala' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Akronim' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Akshar' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Aladin' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Alan Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alata' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alatsi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Albert Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Aldrich' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alef' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alegreya' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Alegreya SC' => array(
			'variants' => array( '400', 'italic', '500', '500italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Alegreya Sans' => array(
			'variants' => array( '100', '100italic', '300', '300italic', '400', 'italic', '500', '500italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alegreya Sans SC' => array(
			'variants' => array( '100', '100italic', '300', '300italic', '400', 'italic', '500', '500italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Aleo' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Alex Brush' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Alexandria' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alfa Slab One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Alice' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Alike' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Alike Angular' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Alkalami' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Alkatra' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Allan' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Allerta' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Allerta Stencil' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Allison' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Allura' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Almarai' => array(
			'variants' => array( '300', '400', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Almendra' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Almendra Display' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Almendra SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Alumni Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alumni Sans Collegiate One' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alumni Sans Inline One' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'display',
		),
	),
	array(
		'Alumni Sans Pinstripe' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Alumni Sans SC' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Amarante' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Amaranth' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Amatic SC' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Amethysta' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Amiko' => array(
			'variants' => array( '400', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Amiri' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Amiri Quran' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Amita' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Anaheim' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ancizar Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ancizar Serif' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Andada Pro' => array(
			'variants' => array( '400', '500', '600', '700', '800', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Andika' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Bangla' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Devanagari' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Gujarati' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Gurmukhi' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Kannada' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Latin' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Malayalam' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Odia' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Tamil' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anek Telugu' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Angkor' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Annapurna SIL' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Annie Use Your Telescope' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Anonymous Pro' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Anta' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Antic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Antic Didone' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Antic Slab' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Anton' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anton SC' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Antonio' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anuphan' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Anybody' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'display',
		),
	),
	array(
		'Aoboshi One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Arapey' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Arbutus' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Arbutus Slab' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Architects Daughter' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Archivo' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Archivo Black' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Archivo Narrow' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Are You Serious' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Aref Ruqaa' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Aref Ruqaa Ink' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Arima' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Arimo' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Arizonia' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Armata' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Arsenal' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Arsenal SC' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Artifika' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Arvo' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Arya' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Asap' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Asap Condensed' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Asar' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Asimovian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Asset' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Assistant' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Asta Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Astloch' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Asul' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Athiti' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Atkinson Hyperlegible' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Atkinson Hyperlegible Mono' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Atkinson Hyperlegible Next' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Atma' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Atomic Age' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Aubrey' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Audiowide' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Autour One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Average' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Average Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Averia Gruesa Libre' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Averia Libre' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Averia Sans Libre' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Averia Serif Libre' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Azeret Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'B612' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'B612 Mono' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'BBH Sans Bartle' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'BBH Sans Bogle' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'BBH Sans Hegarty' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'BIZ UDGothic' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'BIZ UDMincho' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'BIZ UDPGothic' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'BIZ UDPMincho' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Babylonica' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bacasime Antique' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Bad Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Badeen Display' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bagel Fat One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bahiana' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bahianita' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bai Jamjuree' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Bakbak One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ballet' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Baloo 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Bhai 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Bhaijaan 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Bhaina 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Chettan 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Da 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Paaji 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Tamma 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Tammudu 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Baloo Thambi 2' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Balsamiq Sans' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Balthazar' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Bangers' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Barlow' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Barlow Condensed' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Barlow Semi Condensed' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Barriecito' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Barrio' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Basic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Baskervville' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Baskervville SC' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Battambang' => array(
			'variants' => array( '100', '300', '400', '700', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Baumans' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bayon' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Be Vietnam Pro' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Beau Rivage' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bebas Neue' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Beiruti' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Belanosima' => array(
			'variants' => array( '400', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Belgrano' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Bellefair' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Belleza' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Bellota' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Bellota Text' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'BenchNine' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Benne' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Bentham' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Berkshire Swash' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Besley' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Beth Ellen' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bevan' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'BhuTuka Expanded One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Big Shoulders' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Big Shoulders Inline' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Big Shoulders Stencil' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bigelow Rules' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bigshot One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bilbo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bilbo Swash Caps' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'BioRhyme' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'BioRhyme Expanded' => array(
			'variants' => array( '200', '300', '400', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Birthstone' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Birthstone Bounce' => array(
			'variants' => array( '400', '500' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Biryani' => array(
			'variants' => array( '200', '300', '400', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Bitcount' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Grid Double' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Grid Double Ink' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Grid Single' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Grid Single Ink' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Ink' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Prop Double' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Prop Double Ink' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Prop Single' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Prop Single Ink' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Single' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitcount Single Ink' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Bitter' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Black And White Picture' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Black Han Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Black Ops One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Blaka' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Blaka Hollow' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Blaka Ink' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Blinker' => array(
			'variants' => array( '100', '200', '300', '400', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Bodoni Moda' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Bodoni Moda SC' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Bokor' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Boldonse' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bona Nova' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Bona Nova SC' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Bonbon' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bonheur Royale' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Boogaloo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Borel' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bowlby One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bowlby One SC' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Braah One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Brawler' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Bree Serif' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Bricolage Grotesque' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Bruno Ace' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bruno Ace SC' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Brygada 1918' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Bubblegum Sans' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bubbler One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Buda' => array(
			'variants' => array( '300' ),
			'category' => 'display',
		),
	),
	array(
		'Buenard' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Bungee' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bungee Hairline' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bungee Inline' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bungee Outline' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bungee Shade' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bungee Spice' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Bungee Tint' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Butcherman' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Butterfly Kids' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Bytesized' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cabin' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cabin Condensed' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cabin Sketch' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Cactus Classical Serif' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Caesar Dressing' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cagliostro' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cairo' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cairo Play' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cal Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Caladea' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Calistoga' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Calligraffitti' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Cambay' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cambo' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Candal' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cantarell' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cantata One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Cantora One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Caprasimo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Capriola' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Caramel' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Carattere' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Cardo' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Carlito' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Carme' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Carrois Gothic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Carrois Gothic SC' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Carter One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cascadia Code' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cascadia Mono' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Castoro' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Castoro Titling' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Catamaran' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Caudex' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Caveat' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Caveat Brush' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Cedarville Cursive' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ceviche One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Chakra Petch' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Changa' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Changa One' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'display',
		),
	),
	array(
		'Chango' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Charis SIL' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Charm' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Charmonman' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Chathura' => array(
			'variants' => array( '100', '300', '400', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Chau Philomene One' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Chela One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Chelsea Market' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Chenla' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cherish' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Cherry Bomb One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cherry Cream Soda' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cherry Swash' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Chewy' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Chicle' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Chilanka' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Chiron GoRound TC' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Chiron Hei HK' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Chiron Sung HK' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Chivo' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Chivo Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Chocolate Classical Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Chokokutai' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Chonburi' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cinzel' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Cinzel Decorative' => array(
			'variants' => array( '400', '700', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Clicker Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Climate Crisis' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Coda' => array(
			'variants' => array( '400', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Codystar' => array(
			'variants' => array( '300', '400' ),
			'category' => 'display',
		),
	),
	array(
		'Coiny' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Combo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Comfortaa' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Comforter' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Comforter Brush' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Comic Neue' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Comic Relief' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Coming Soon' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Comme' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Commissioner' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Concert One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Condiment' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Content' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Contrail One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Convergence' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cookie' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Copse' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Coral Pixels' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Corben' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Corinthia' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Cormorant' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Cormorant Garamond' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Cormorant Infant' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Cormorant SC' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Cormorant Unicase' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Cormorant Upright' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Cossette Texte' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cossette Titre' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Courgette' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Courier Prime' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Cousine' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Coustard' => array(
			'variants' => array( '400', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Covered By Your Grace' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Crafty Girls' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Creepster' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Crete Round' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Crimson Pro' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Crimson Text' => array(
			'variants' => array( '400', 'italic', '600', '600italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Croissant One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Crushed' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cuprum' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Cute Font' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Cutive' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Cutive Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'DM Mono' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '500', '500italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'DM Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'DM Serif Display' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'DM Serif Text' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Dai Banna SIL' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Damion' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Dancing Script' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Danfo' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Dangrek' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Darker Grotesque' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Darumadrop One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'David Libre' => array(
			'variants' => array( '400', '500', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Dawning of a New Day' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Days One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Dekko' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Dela Gothic One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Delicious Handrawn' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Delius' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Delius Swash Caps' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Delius Unicase' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Della Respira' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Denk One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Devonshire' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Dhurjati' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Didact Gothic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Diphylleia' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Diplomata' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Diplomata SC' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Do Hyeon' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Dokdo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Domine' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Donegal One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Dongle' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Doppio One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Dorsa' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Dosis' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'DotGothic16' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Doto' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Dr Sugiyama' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Duru Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'DynaPuff' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Dynalight' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'EB Garamond' => array(
			'variants' => array( '400', '500', '600', '700', '800', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Eagle Lake' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'East Sea Dokdo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Eater' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Economica' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Eczar' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Edu AU VIC WA NT Arrows' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu AU VIC WA NT Dots' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu AU VIC WA NT Guides' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu AU VIC WA NT Hand' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu AU VIC WA NT Pre' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu NSW ACT Cursive' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu NSW ACT Foundation' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu NSW ACT Hand Pre' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu QLD Beginner' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu QLD Hand' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu SA Beginner' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu SA Hand' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu TAS Beginner' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu VIC WA NT Beginner' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu VIC WA NT Hand' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Edu VIC WA NT Hand Pre' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'El Messiri' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Electrolize' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Elsie' => array(
			'variants' => array( '400', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Elsie Swash Caps' => array(
			'variants' => array( '400', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Emblema One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Emilys Candy' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Encode Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Encode Sans Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Encode Sans Expanded' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Encode Sans SC' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Encode Sans Semi Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Encode Sans Semi Expanded' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Engagement' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Englebert' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Enriqueta' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Ephesis' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Epilogue' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Epunda Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Epunda Slab' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Erica One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Esteban' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Estonia' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Euphoria Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ewert' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Exile' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Exo' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Exo 2' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Expletus Sans' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Explora' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Faculty Glyphic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fahkwang' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Familjen Grotesk' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fanwood Text' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Farro' => array(
			'variants' => array( '300', '400', '500', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Farsan' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fascinate' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fascinate Inline' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Faster One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fasthand' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fauna One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Faustina' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Federant' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Federo' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Felipa' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Fenix' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Festive' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Figtree' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Finger Paint' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Finlandica' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fira Code' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Fira Mono' => array(
			'variants' => array( '400', '500', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Fira Sans' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fira Sans Condensed' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fira Sans Extra Condensed' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fjalla One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fjord One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Flamenco' => array(
			'variants' => array( '300', '400' ),
			'category' => 'display',
		),
	),
	array(
		'Flavors' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fleur De Leah' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Flow Block' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Flow Circular' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Flow Rounded' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Foldit' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Fondamento' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Fontdiner Swanky' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Forum' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fragment Mono' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Francois One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Frank Ruhl Libre' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Fraunces' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Freckle Face' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fredericka the Great' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fredoka' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Freehand' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Freeman' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fresca' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Frijole' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fruktur' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'display',
		),
	),
	array(
		'Fugaz One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Fuggles' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Funnel Display' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Funnel Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fustat' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Fuzzy Bubbles' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'GFS Didot' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'GFS Neohellenic' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ga Maamli' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gabarito' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Gabriela' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Gaegu' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Gafata' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gajraj One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Galada' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Galdeano' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Galindo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gamja Flower' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Gantari' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gasoek One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gayathri' => array(
			'variants' => array( '100', '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Geist' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Geist Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'monospace',
		),
	),
	array(
		'Gelasio' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Gemunu Libre' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Genos' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gentium Book Plus' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Gentium Plus' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Geo' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Geologica' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Georama' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Geostar' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Geostar Fill' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Germania One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gideon Roman' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gidole' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gidugu' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gilda Display' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Girassol' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Give You Glory' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Glass Antiqua' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Glegoo' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Gloock' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Gloria Hallelujah' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Glory' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gluten' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Goblin One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gochi Hand' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Goldman' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Golos Text' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Google Sans Code' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Gorditas' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Gothic A1' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gotu' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Goudy Bookletter 1911' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Gowun Batang' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Gowun Dodum' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Graduate' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Grand Hotel' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Grandiflora One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Grandstander' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'display',
		),
	),
	array(
		'Grape Nuts' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Gravitas One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Great Vibes' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Grechen Fuemen' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Grenze' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Grenze Gotisch' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Grey Qo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Griffy' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gruppo' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gudea' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gugi' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Gulzar' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Gupter' => array(
			'variants' => array( '400', '500', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Gurajada' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Gwendolyn' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Habibi' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Hachi Maru Pop' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Hahmlet' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Halant' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Hammersmith One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hanalei' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Hanalei Fill' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Handjet' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Handlee' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Hanken Grotesk' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hanuman' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Happy Monkey' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Harmattan' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Headland One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Hedvig Letters Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hedvig Letters Serif' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Heebo' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Henny Penny' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Hepta Slab' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Herr Von Muellerhoff' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Hi Melody' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Hina Mincho' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Hind' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hind Guntur' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hind Madurai' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hind Mysuru' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hind Siliguri' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hind Vadodara' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Holtwood One SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Homemade Apple' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Homenaje' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Honk' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Host Grotesk' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hubballi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hubot Sans' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Huninn' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Hurricane' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'IBM Plex Mono' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'IBM Plex Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans Arabic' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans Condensed' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans Devanagari' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans Hebrew' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans JP' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans KR' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans Thai' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Sans Thai Looped' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'IBM Plex Serif' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell DW Pica' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell DW Pica SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell Double Pica' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell Double Pica SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell English' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell English SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell French Canon' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell French Canon SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell Great Primer' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'IM Fell Great Primer SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Iansui' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ibarra Real Nova' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Iceberg' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Iceland' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Imbue' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Imperial Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Imprima' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Inclusive Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Inconsolata' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'monospace',
		),
	),
	array(
		'Inder' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Indie Flower' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ingrid Darling' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Inika' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Inknut Antiqua' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Inria Sans' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Inria Serif' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Inspiration' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Instrument Sans' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Instrument Serif' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Intel One Mono' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Inter' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Inter Tight' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Irish Grover' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Island Moments' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Istok Web' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Italiana' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Italianno' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Itim' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Jacquard 12' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jacquard 12 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jacquard 24' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jacquard 24 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jacquarda Bastarda 9' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jacquarda Bastarda 9 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jacques Francois' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Jacques Francois Shadow' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jaini' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jaini Purva' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jaldi' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Jaro' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Jersey 10' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 10 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 15' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 15 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 20' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 20 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 25' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jersey 25 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'JetBrains Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Jim Nightshade' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Joan' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Jockey One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Jolly Lodger' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jomhuria' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jomolhari' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Josefin Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Josefin Slab' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Jost' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Joti One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Jua' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Judson' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Julee' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Julius Sans One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Junge' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Jura' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Just Another Hand' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Just Me Again Down Here' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'K2D' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kablammo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kadwa' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kaisei Decol' => array(
			'variants' => array( '400', '500', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kaisei HarunoUmi' => array(
			'variants' => array( '400', '500', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kaisei Opti' => array(
			'variants' => array( '400', '500', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kaisei Tokumin' => array(
			'variants' => array( '400', '500', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Kalam' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Kalnia' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kalnia Glaze' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Kameron' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kanchenjunga' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kanit' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kantumruy Pro' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kapakana' => array(
			'variants' => array( '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Karantina' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Karla' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Karla Tamil Inclined' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Karla Tamil Upright' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Karma' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Katibeh' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kaushan Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Kavivanar' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Kavoon' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kay Pho Du' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kdam Thmor Pro' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Keania One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kelly Slab' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kenia' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Khand' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Khmer' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Khula' => array(
			'variants' => array( '300', '400', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kings' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Kirang Haerang' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kite One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kiwi Maru' => array(
			'variants' => array( '300', '400', '500' ),
			'category' => 'serif',
		),
	),
	array(
		'Klee One' => array(
			'variants' => array( '400', '600' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Knewave' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'KoHo' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kodchasan' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kode Mono' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Koh Santepheap' => array(
			'variants' => array( '100', '300', '400', '700', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Kolker Brush' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Konkhmer Sleokchher' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kosugi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kosugi Maru' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kotta One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Koulen' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kranky' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kreon' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Kristi' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Krona One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Krub' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kufam' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kulim Park' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kumar One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kumar One Outline' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Kumbh Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Kurale' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'LXGW Marker Gothic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'LXGW WenKai Mono TC' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'LXGW WenKai TC' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'La Belle Aurore' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Labrada' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Lacquer' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Laila' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Lakki Reddy' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Lalezar' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lancelot' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Langar' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Lateef' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Lato' => array(
			'variants' => array( '100', '100italic', '300', '300italic', '400', 'italic', '700', '700italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lavishly Yours' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'League Gothic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'League Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'League Spartan' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Leckerli One' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ledger' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Lekton' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Lemon' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Lemonada' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Lexend' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Deca' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Exa' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Giga' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Mega' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Peta' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Tera' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lexend Zetta' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Libertinus Keyboard' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libertinus Math' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libertinus Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Libertinus Sans' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Libertinus Serif' => array(
			'variants' => array( '400', 'italic', '600', '600italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Libertinus Serif Display' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode 128' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode 128 Text' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode 39' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode 39 Extended' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode 39 Extended Text' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode 39 Text' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Barcode EAN13 Text' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Libre Baskerville' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Libre Bodoni' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Libre Caslon Display' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Libre Caslon Text' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Libre Franklin' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Licorice' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Life Savers' => array(
			'variants' => array( '400', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Lilita One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Lily Script One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Limelight' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Linden Hill' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Linefont' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Lisu Bosa' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Liter' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Literata' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Liu Jian Mao Cao' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Livvic' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lobster' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Lobster Two' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'display',
		),
	),
	array(
		'Londrina Outline' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Londrina Shadow' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Londrina Sketch' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Londrina Solid' => array(
			'variants' => array( '100', '300', '400', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Long Cang' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Lora' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Love Light' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Love Ya Like A Sister' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Loved by the King' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Lovers Quarrel' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Luckiest Guy' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Lugrasimo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Lumanosimo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Lunasima' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Lusitana' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Lustria' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Luxurious Roman' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Luxurious Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'M PLUS 1' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'M PLUS 1 Code' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'M PLUS 1p' => array(
			'variants' => array( '100', '300', '400', '500', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'M PLUS 2' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'M PLUS Code Latin' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'M PLUS Rounded 1c' => array(
			'variants' => array( '100', '300', '400', '500', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ma Shan Zheng' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Macondo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Macondo Swash Caps' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Mada' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Madimi One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Magra' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Maiden Orange' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Maitree' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Major Mono Display' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Mako' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mali' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mallanna' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Maname' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Mandali' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Manjari' => array(
			'variants' => array( '100', '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Manrope' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mansalva' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Manuale' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Manufacturing Consent' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Marcellus' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Marcellus SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Marck Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Margarine' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Marhey' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Markazi Text' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Marko One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Marmelad' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Martel' => array(
			'variants' => array( '200', '300', '400', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Martel Sans' => array(
			'variants' => array( '200', '300', '400', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Martian Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'monospace',
		),
	),
	array(
		'Marvel' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Matangi' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mate' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Mate SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Matemasie' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Material Icons' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Icons Outlined' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Icons Round' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Icons Sharp' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Icons Two Tone' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Symbols' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Symbols Outlined' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Symbols Rounded' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Material Symbols Sharp' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Maven Pro' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'McLaren' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Mea Culpa' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Meddon' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'MedievalSharp' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Medula One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Meera Inimai' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Megrim' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Meie Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Menbere' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Meow Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Merienda' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Merriweather' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Merriweather Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Metal' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Metal Mania' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Metamorphous' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Metrophobic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Michroma' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Micro 5' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Micro 5 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Milonga' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Miltonian' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Miltonian Tattoo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Mina' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mingzat' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Miniver' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Miriam Libre' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mirza' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Miss Fajardose' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mitr' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mochiy Pop One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mochiy Pop P One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Modak' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Modern Antiqua' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Moderustic' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mogra' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Mohave' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Moirai One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Molengo' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Molle' => array(
			'variants' => array( 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mona Sans' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Monda' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Monofett' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Monomakh' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Monomaniac One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Monoton' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Monsieur La Doulaise' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Montaga' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Montagu Slab' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'MonteCarlo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Montez' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Montserrat' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Montserrat Alternates' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Montserrat Underline' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Moo Lah Lah' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Mooli' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Moon Dance' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Moul' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Moulpali' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mountains of Christmas' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Mouse Memoirs' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mozilla Headline' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mozilla Text' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mr Bedfort' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mr Dafoe' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mr De Haviland' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mrs Saint Delafield' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mrs Sheppards' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ms Madi' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mukta' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mukta Mahee' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mukta Malar' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mukta Vaani' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Mulish' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Murecho' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'MuseoModerno' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'display',
		),
	),
	array(
		'My Soul' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mynerve' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Mystery Quest' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'NTR' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nabla' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Namdhinggo' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Nanum Brush Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Nanum Gothic' => array(
			'variants' => array( '400', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nanum Gothic Coding' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Nanum Myeongjo' => array(
			'variants' => array( '400', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Nanum Pen Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Narnoor' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nata Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'National Park' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Neonderthaw' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Nerko One' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Neucha' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Neuton' => array(
			'variants' => array( '200', '300', '400', 'italic', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'New Amsterdam' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'New Rocker' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'New Tegomin' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'News Cycle' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Newsreader' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Niconne' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Niramit' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nixie One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nobile' => array(
			'variants' => array( '400', 'italic', '500', '500italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nokora' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Norican' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Nosifer' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Notable' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nothing You Could Do' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Noticia Text' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Color Emoji' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Emoji' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Kufi Arabic' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Music' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Naskh Arabic' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Nastaliq Urdu' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Rashi Hebrew' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Adlam' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Adlam Unjoined' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Anatolian Hieroglyphs' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Arabic' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Armenian' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Avestan' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Balinese' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Bamum' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Bassa Vah' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Batak' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Bengali' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Bhaiksuki' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Brahmi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Buginese' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Buhid' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Canadian Aboriginal' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Carian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Caucasian Albanian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Chakma' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Cham' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Cherokee' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Chorasmian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Coptic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Cuneiform' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Cypriot' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Cypro Minoan' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Deseret' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Devanagari' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Display' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Duployan' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Egyptian Hieroglyphs' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Elbasan' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Elymaic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Ethiopic' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Georgian' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Glagolitic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Gothic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Grantha' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Gujarati' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Gunjala Gondi' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Gurmukhi' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans HK' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Hanifi Rohingya' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Hanunoo' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Hatran' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Hebrew' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Imperial Aramaic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Indic Siyaq Numbers' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Inscriptional Pahlavi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Inscriptional Parthian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans JP' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Javanese' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans KR' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Kaithi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Kannada' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Kawi' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Kayah Li' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Kharoshthi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Khmer' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Khojki' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Khudawadi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Lao' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Lao Looped' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Lepcha' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Limbu' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Linear A' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Linear B' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Lisu' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Lycian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Lydian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mahajani' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Malayalam' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mandaic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Manichaean' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Marchen' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Masaram Gondi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Math' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mayan Numerals' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Medefaidrin' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Meetei Mayek' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mende Kikakui' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Meroitic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Miao' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Modi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mongolian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Mro' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Multani' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Myanmar' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans NKo' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans NKo Unjoined' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Nabataean' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Nag Mundari' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Nandinagari' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans New Tai Lue' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Newa' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Nushu' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Ogham' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Ol Chiki' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old Hungarian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old Italic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old North Arabian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old Permic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old Persian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old Sogdian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old South Arabian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Old Turkic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Oriya' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Osage' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Osmanya' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Pahawh Hmong' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Palmyrene' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Pau Cin Hau' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans PhagsPa' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Phoenician' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Psalter Pahlavi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Rejang' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Runic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans SC' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Samaritan' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Saurashtra' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Sharada' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Shavian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Siddham' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans SignWriting' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Sinhala' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Sogdian' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Sora Sompeng' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Soyombo' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Sundanese' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Sunuwar' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Syloti Nagri' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Symbols' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Symbols 2' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Syriac' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Syriac Eastern' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans TC' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tagalog' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tagbanwa' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tai Le' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tai Tham' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tai Viet' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Takri' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tamil' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tamil Supplement' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tangsa' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Telugu' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Thaana' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Thai' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Thai Looped' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tifinagh' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Tirhuta' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Ugaritic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Vai' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Vithkuqi' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Wancho' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Warang Citi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Yi' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Sans Zanabazar Square' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Serif' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Ahom' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Armenian' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Balinese' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Bengali' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Devanagari' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Display' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Dives Akuru' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Dogra' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Ethiopic' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Georgian' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Grantha' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Gujarati' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Gurmukhi' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif HK' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Hebrew' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Hentaigana' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif JP' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif KR' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Kannada' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Khitan Small Script' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Khmer' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Khojki' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Lao' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Makasar' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Malayalam' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Myanmar' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif NP Hmong' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Old Uyghur' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Oriya' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Ottoman Siyaq' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif SC' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Sinhala' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif TC' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Tamil' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Tangut' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Telugu' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Thai' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Tibetan' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Todhri' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Toto' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Vithkuqi' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Serif Yezidi' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Noto Traditional Nushu' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Noto Znamenny Musical Notation' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nova Cut' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nova Flat' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nova Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Nova Oval' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nova Round' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nova Script' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nova Slim' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Nova Square' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Numans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nunito' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nunito Sans' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Nuosu SIL' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Odibee Sans' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Odor Mean Chey' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Offside' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Oi' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ojuju' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Old Standard TT' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Oldenburg' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ole' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Oleo Script' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Oleo Script Swash Caps' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Onest' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Oooh Baby' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Open Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Oranienbaum' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Orbit' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Orbitron' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Oregano' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'display',
		),
	),
	array(
		'Orelega One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Orienta' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Original Surfer' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Oswald' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Outfit' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Over the Rainbow' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Overlock' => array(
			'variants' => array( '400', 'italic', '700', '700italic', '900', '900italic' ),
			'category' => 'display',
		),
	),
	array(
		'Overlock SC' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Overpass' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Overpass Mono' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'monospace',
		),
	),
	array(
		'Ovo' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Oxanium' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Oxygen' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Oxygen Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'PT Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'PT Sans' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'PT Sans Caption' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'PT Sans Narrow' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'PT Serif' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'PT Serif Caption' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Pacifico' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Padauk' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Padyakke Expanded One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Palanquin' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Palanquin Dark' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Palette Mosaic' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pangolin' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Paprika' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Parastoo' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Parisienne' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Parkinsans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Passero One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Passion One' => array(
			'variants' => array( '400', '700', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Passions Conflict' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Pathway Extreme' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Pathway Gothic One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Patrick Hand' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Patrick Hand SC' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Pattaya' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Patua One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pavanam' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Paytone One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Peddana' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Peralta' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Permanent Marker' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Petemoss' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Petit Formal Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Petrona' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Phetsarath' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Philosopher' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Phudu' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Piazzolla' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Piedra' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pinyon Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Pirata One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pixelify Sans' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Plaster' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Platypi' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Play' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Playball' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Playfair' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Playfair Display' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Playfair Display SC' => array(
			'variants' => array( '400', 'italic', '700', '700italic', '900', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Playpen Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playpen Sans Arabic' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playpen Sans Deva' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playpen Sans Hebrew' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playpen Sans Thai' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AR' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AR Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AT' => array(
			'variants' => array( '100', '200', '300', '400', '100italic', '200italic', '300italic', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AT Guides' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU NSW' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU NSW Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU QLD' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU QLD Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU SA' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU SA Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU TAS' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU TAS Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU VIC' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite AU VIC Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite BE VLG' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite BE VLG Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite BE WAL' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite BE WAL Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite BR' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite BR Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CA' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CA Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CL' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CL Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CO' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CO Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CU' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CU Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CZ' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite CZ Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE Grund' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE Grund Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE LA' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE LA Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE SAS' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE SAS Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE VA' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DE VA Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DK Loopet' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DK Loopet Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DK Uloopet' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite DK Uloopet Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ES' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ES Deco' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ES Deco Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ES Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite FR Moderne' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite FR Moderne Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite FR Trad' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite FR Trad Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite GB J' => array(
			'variants' => array( '100', '200', '300', '400', '100italic', '200italic', '300italic', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite GB J Guides' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite GB S' => array(
			'variants' => array( '100', '200', '300', '400', '100italic', '200italic', '300italic', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite GB S Guides' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite HR' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite HR Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite HR Lijeva' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite HR Lijeva Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite HU' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite HU Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ID' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ID Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IE' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IE Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IN' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IN Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IS' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IS Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IT Moderna' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IT Moderna Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IT Trad' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite IT Trad Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite MX' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite MX Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NG Modern' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NG Modern Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NL' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NL Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NO' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NO Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NZ' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite NZ Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite PE' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite PE Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite PL' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite PL Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite PT' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite PT Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite RO' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite RO Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite SK' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite SK Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite TZ' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite TZ Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite US Modern' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite US Modern Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite US Trad' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite US Trad Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite VN' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite VN Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ZA' => array(
			'variants' => array( '100', '200', '300', '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Playwrite ZA Guides' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Plus Jakarta Sans' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Pochaevsk' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Podkova' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Poetsen One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Poiret One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Poller One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Poltawski Nowy' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Poly' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Pompiere' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ponnala' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ponomar' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pontano Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Poor Story' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Poppins' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Port Lligat Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Port Lligat Slab' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Potta One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pragati Narrow' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Praise' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Prata' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Preahvihear' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Press Start 2P' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Pridi' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Princess Sofia' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Prociono' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Prompt' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Prosto One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Protest Guerrilla' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Protest Revolution' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Protest Riot' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Protest Strike' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Proza Libre' => array(
			'variants' => array( '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Public Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Puppies Play' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Puritan' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Purple Purse' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Qahiri' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Quando' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Quantico' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Quattrocento' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Quattrocento Sans' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Questrial' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Quicksand' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Quintessential' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Qwigley' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Qwitcher Grypen' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'REM' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Racing Sans One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Radio Canada' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Radio Canada Big' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Radley' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Rajdhani' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rakkas' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Raleway' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Raleway Dots' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ramabhadra' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ramaraja' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Rambla' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rammetto One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rampart One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ranchers' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rancho' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ranga' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Rasa' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Rationale' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ravi Prakash' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Readex Pro' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Recursive' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Red Hat Display' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Red Hat Mono' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Red Hat Text' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Red Rose' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Redacted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Redacted Script' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Reddit Mono' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'monospace',
		),
	),
	array(
		'Reddit Sans' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Reddit Sans Condensed' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Redressed' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Reem Kufi' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Reem Kufi Fun' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Reem Kufi Ink' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Reenie Beanie' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Reggae One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rethink Sans' => array(
			'variants' => array( '400', '500', '600', '700', '800', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Revalia' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rhodium Libre' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Ribeye' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ribeye Marrow' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Righteous' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Risque' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Road Rage' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Roboto' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Roboto Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Roboto Flex' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Roboto Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Roboto Serif' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Roboto Slab' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Rochester' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Rock 3D' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rock Salt' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'RocknRoll One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rokkitt' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Romanesco' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ropa Sans' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rosario' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rosarivo' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Rouge Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Rowdies' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Rozha One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Rubik' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rubik 80s Fade' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Beastly' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Broken Fax' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Bubbles' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Burned' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Dirt' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Distressed' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Doodle Shadow' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Doodle Triangles' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Gemstones' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Glitch' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Glitch Pop' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Iso' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Lines' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Maps' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Marker Hatch' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Maze' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Microbe' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Mono One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rubik Moonrocks' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Pixels' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Puddles' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Scribble' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Spray Paint' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Storm' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Vinyl' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Rubik Wet Paint' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Ruda' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rufina' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Ruge Boogie' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ruluko' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Rum Raisin' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ruslan Display' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Russo One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ruthie' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ruwudu' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Rye' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'STIX Two Text' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'SUSE' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'SUSE Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sacramento' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Sahitya' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Sail' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Saira' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Saira Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Saira Extra Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Saira Semi Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Saira Stencil One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Salsa' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sanchez' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Sancreek' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sankofa Display' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sansation' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sansita' => array(
			'variants' => array( '400', 'italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sansita Swashed' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Sarabun' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sarala' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sarina' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sarpanch' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sassy Frass' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Satisfy' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Savate' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sawarabi Gothic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sawarabi Mincho' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Scada' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Scheherazade New' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Schibsted Grotesk' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Schoolbell' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Scope One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Seaweed Script' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Secular One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sedan' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Sedan SC' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Sedgwick Ave' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Sedgwick Ave Display' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Sen' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Send Flowers' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Sevillana' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Seymour One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Shadows Into Light' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Shadows Into Light Two' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Shafarik' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Shalimar' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Shantell Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'display',
		),
	),
	array(
		'Shanti' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Share' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Share Tech' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Share Tech Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Shippori Antique' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Shippori Antique B1' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Shippori Mincho' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Shippori Mincho B1' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Shizuru' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Shojumaru' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Short Stack' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Shrikhand' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Siemreap' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sigmar' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sigmar One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Signika' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Signika Negative' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Silkscreen' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Simonetta' => array(
			'variants' => array( '400', 'italic', '900', '900italic' ),
			'category' => 'display',
		),
	),
	array(
		'Single Day' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sintony' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sirin Stencil' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sirivennela' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Six Caps' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sixtyfour' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Sixtyfour Convergence' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Skranji' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Slabo 13px' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Slabo 27px' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Slackey' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Slackside One' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Smokum' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Smooch' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Smooch Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Smythe' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sniglet' => array(
			'variants' => array( '400', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Snippet' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Snowburst One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sofadi One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sofia' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Sofia Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sofia Sans Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sofia Sans Extra Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sofia Sans Semi Condensed' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Solitreo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Solway' => array(
			'variants' => array( '300', '400', '500', '700', '800' ),
			'category' => 'serif',
		),
	),
	array(
		'Sometype Mono' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Song Myung' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Sono' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sonsie One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sora' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sorts Mill Goudy' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Sour Gummy' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Source Code Pro' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Source Sans 3' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Source Serif 4' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Space Grotesk' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Space Mono' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Special Elite' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Special Gothic' => array(
			'variants' => array( '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Special Gothic Condensed One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Special Gothic Expanded One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Spectral' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Spectral SC' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Spicy Rice' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Spinnaker' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Spirax' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Splash' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Spline Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Spline Sans Mono' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Squada One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Square Peg' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Sree Krushnadevaraya' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Sriracha' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Srisakdi' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Staatliches' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Stalemate' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Stalinist One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Stardos Stencil' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Stick' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Stick No Bills' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Stint Ultra Condensed' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Stint Ultra Expanded' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Stoke' => array(
			'variants' => array( '300', '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Story Script' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Strait' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Style Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Stylish' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sue Ellen Francisco' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Suez One' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Sulphur Point' => array(
			'variants' => array( '300', '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sumana' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Sunflower' => array(
			'variants' => array( '300', '500', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Sunshiney' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Supermercado One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Sura' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Suranna' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Suravaram' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Suwannaphum' => array(
			'variants' => array( '100', '300', '400', '700', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Swanky and Moo Moo' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Syncopate' => array(
			'variants' => array( '400', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Syne' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Syne Mono' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Syne Tactile' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'TASA Explorer' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'TASA Orbiter' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tac One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tagesschrift' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Tai Heritage Pro' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
	array(
		'Tajawal' => array(
			'variants' => array( '200', '300', '400', '500', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tangerine' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Tapestry' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Taprom' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Tauri' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Taviraj' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Teachers' => array(
			'variants' => array( '400', '500', '600', '700', '800', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Teko' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tektur' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Telex' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tenali Ramakrishna' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tenor Sans' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Text Me One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Texturina' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Thasadith' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'The Girl Next Door' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'The Nautigal' => array(
			'variants' => array( '400', '700' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Tienne' => array(
			'variants' => array( '400', '700', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'TikTok Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tillana' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Tilt Neon' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Tilt Prism' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Tilt Warp' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Timmana' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tinos' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiny5' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tiro Bangla' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Devanagari Hindi' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Devanagari Marathi' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Devanagari Sanskrit' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Gurmukhi' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Kannada' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Tamil' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tiro Telugu' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Tirra' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Titan One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Titillium Web' => array(
			'variants' => array( '200', '200italic', '300', '300italic', '400', 'italic', '600', '600italic', '700', '700italic', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tomorrow' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tourney' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'display',
		),
	),
	array(
		'Trade Winds' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Train One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Triodion' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Trirong' => array(
			'variants' => array( '100', '100italic', '200', '200italic', '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic', '900', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Trispace' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Trocchi' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Trochut' => array(
			'variants' => array( '400', 'italic', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Truculenta' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Trykker' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Tsukimi Rounded' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tuffy' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Tulpen One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Turret Road' => array(
			'variants' => array( '200', '300', '400', '500', '700', '800' ),
			'category' => 'display',
		),
	),
	array(
		'Twinkle Star' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Ubuntu' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '500', '500italic', '700', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ubuntu Condensed' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ubuntu Mono' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Ubuntu Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ubuntu Sans Mono' => array(
			'variants' => array( '400', '500', '600', '700', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Uchen' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Ultra' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Unbounded' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Uncial Antiqua' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Underdog' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Unica One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'UnifrakturCook' => array(
			'variants' => array( '700' ),
			'category' => 'display',
		),
	),
	array(
		'UnifrakturMaguntia' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Unkempt' => array(
			'variants' => array( '400', '700' ),
			'category' => 'display',
		),
	),
	array(
		'Unlock' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Unna' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'UoqMunThenKhung' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Updock' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Urbanist' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'VT323' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Vampiro One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Varela' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Varela Round' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Varta' => array(
			'variants' => array( '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Vast Shadow' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Vazirmatn' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Vend Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Vesper Libre' => array(
			'variants' => array( '400', '500', '700', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Viaoda Libre' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Vibes' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Vibur' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Victor Mono' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Vidaloka' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Viga' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Vina Sans' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Voces' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Volkhov' => array(
			'variants' => array( '400', 'italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Vollkorn' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Vollkorn SC' => array(
			'variants' => array( '400', '600', '700', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Voltaire' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Vujahday Script' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'WDXL Lubrifont JP N' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'WDXL Lubrifont SC' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'WDXL Lubrifont TC' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Waiting for the Sunrise' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Wallpoet' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Walter Turncoat' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Warnes' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Water Brush' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Waterfall' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Wavefont' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'display',
		),
	),
	array(
		'Wellfleet' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Wendy One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Whisper' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'WindSong' => array(
			'variants' => array( '400', '500' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Winky Rough' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Winky Sans' => array(
			'variants' => array( '300', '400', '500', '600', '700', '800', '900', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Wire One' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Wittgenstein' => array(
			'variants' => array( '400', '500', '600', '700', '800', '900', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Wix Madefor Display' => array(
			'variants' => array( '400', '500', '600', '700', '800' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Wix Madefor Text' => array(
			'variants' => array( '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic', '800', '800italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Work Sans' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Workbench' => array(
			'variants' => array( '400' ),
			'category' => 'monospace',
		),
	),
	array(
		'Xanh Mono' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'monospace',
		),
	),
	array(
		'Yaldevi' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Yanone Kaffeesatz' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Yantramanav' => array(
			'variants' => array( '100', '300', '400', '500', '700', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Yarndings 12' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yarndings 12 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yarndings 20' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yarndings 20 Charted' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yatra One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yellowtail' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Yeon Sung' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yeseva One' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Yesteryear' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Yomogi' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Young Serif' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Yrsa' => array(
			'variants' => array( '300', '400', '500', '600', '700', '300italic', 'italic', '500italic', '600italic', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Ysabeau' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ysabeau Infant' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ysabeau Office' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900', '100italic', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Ysabeau SC' => array(
			'variants' => array( '100', '200', '300', '400', '500', '600', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Yuji Boku' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Yuji Hentaigana Akari' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Yuji Hentaigana Akebono' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Yuji Mai' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Yuji Syuku' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Yusei Magic' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'ZCOOL KuaiLe' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'ZCOOL QingKe HuangYou' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'ZCOOL XiaoWei' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zain' => array(
			'variants' => array( '200', '300', '300italic', '400', 'italic', '700', '800', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zalando Sans' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zalando Sans Expanded' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zalando Sans SemiExpanded' => array(
			'variants' => array( '200', '300', '400', '500', '600', '700', '800', '900', '200italic', '300italic', 'italic', '500italic', '600italic', '700italic', '800italic', '900italic' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zen Antique' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Zen Antique Soft' => array(
			'variants' => array( '400' ),
			'category' => 'serif',
		),
	),
	array(
		'Zen Dots' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Zen Kaku Gothic Antique' => array(
			'variants' => array( '300', '400', '500', '700', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zen Kaku Gothic New' => array(
			'variants' => array( '300', '400', '500', '700', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zen Kurenaido' => array(
			'variants' => array( '400' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zen Loop' => array(
			'variants' => array( '400', 'italic' ),
			'category' => 'display',
		),
	),
	array(
		'Zen Maru Gothic' => array(
			'variants' => array( '300', '400', '500', '700', '900' ),
			'category' => 'sans-serif',
		),
	),
	array(
		'Zen Old Mincho' => array(
			'variants' => array( '400', '500', '600', '700', '900' ),
			'category' => 'serif',
		),
	),
	array(
		'Zen Tokyo Zoo' => array(
			'variants' => array( '400' ),
			'category' => 'display',
		),
	),
	array(
		'Zeyada' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Zhi Mang Xing' => array(
			'variants' => array( '400' ),
			'category' => 'handwriting',
		),
	),
	array(
		'Zilla Slab' => array(
			'variants' => array( '300', '300italic', '400', 'italic', '500', '500italic', '600', '600italic', '700', '700italic' ),
			'category' => 'serif',
		),
	),
	array(
		'Zilla Slab Highlight' => array(
			'variants' => array( '400', '700' ),
			'category' => 'serif',
		),
	),
);
