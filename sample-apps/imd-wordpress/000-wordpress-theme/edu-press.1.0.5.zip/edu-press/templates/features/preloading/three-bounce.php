<?php
/**
 * Preload Template: three bounce
 *
 * @package Edu_Press
 */
?>

<div class="sk-three-bounce">
	<div class="sk-child sk-bounce1"></div>
	<div class="sk-child sk-bounce2"></div>
	<div class="sk-child sk-bounce3"></div>
</div>
